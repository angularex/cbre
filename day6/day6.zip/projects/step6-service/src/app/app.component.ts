import { Component } from '@angular/core';
import { HeroService } from './hero.service';


@Component({
  selector: 'app-root',
  providers : [HeroService],
  template: `
    <div class="container">
    <h1>Welcome to {{title}}!</h1>
    <hr>
    <app-header [data]="appdata" [version]="appversion"></app-header>
    <hr>
    <app-grid [data]="appdata" [version]="appversion"></app-grid>
    </div>
  `,
  styles: []
})
export class AppComponent {
  title = 'Services in Angular';
  appdata:any;
  appversion:any;

  constructor( private hs:HeroService ){
    this.appdata = this.hs.getData();
    this.appversion = this.hs.getVersion();
  }
}
