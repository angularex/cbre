import { Component, Input } from "@angular/core";
import { HeroService } from "../hero.service";

@Component({
    selector : "app-header",
    providers : [HeroService],
    template : `
    <div>
        <div>Header Component | Header Version : {{ headerVersion }}</div>
        <ul class="nav justify-content-center">
            <li class="nav-item" *ngFor="let hero of herodata">
                <a href="#" class="nav-link">{{ hero.title }}</a>
            </li>
        </ul>
    </div>
    `
})
export class HeaderComp{
    @Input('data') herodata:any = [];
    @Input('version') headerVersion = 0;
    // hs:HeroService = new HeroService()
}