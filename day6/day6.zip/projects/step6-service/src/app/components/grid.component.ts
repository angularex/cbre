import { Component, Input, input } from "@angular/core";
import { HeroService } from "../hero.service";

@Component({
    selector : 'app-grid',
    template : `
    <div>
        <div>Grid Component Version : {{ gridVersion }}</div>
        <table class="table table-striped">
        <thead class="table-dark">
          <tr>
            <th>Sl #</th>
            <th>Title</th>
            <th>Name</th>
            <th>Poster</th>
            <th>City</th>
            <th>Release Date</th>
            <th>Ticket Price</th>
            <th>Movies</th>
          </tr>
        </thead>
        <tbody>
          <tr *ngFor="let hero of herodata">
            <td>{{ hero.sl }}</td>
            <td>{{ hero.title | uppercase }}</td>
            <td>{{ hero.firstname+" "+hero.lastname | lowercase }}</td>
            <td>
              <img width="50" [src]="hero.poster" [alt]="hero.title">
            </td>
            <td>{{ hero.city }}</td>
            <td>{{ hero.releasedate | date : 'dd MMMM yyyy' }}</td>
            <td>{{ hero.ticketprice | currency : "INR " : 'code' : "3.2-3" }}</td>
            <td>{{ hero.movieslist.length }}</td>
          </tr>
        </tbody>
      </table>
    </div>
    `
})
export class GridComp{
   @Input("data") herodata:any = [];
   @Input("version") gridVersion = 0;
    // hs:HeroService = new HeroService()

}