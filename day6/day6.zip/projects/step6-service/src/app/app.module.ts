import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { HeaderComp } from './components/header.component';
import { GridComp } from './components/grid.component';

@NgModule({
  declarations: [ AppComponent, HeaderComp, GridComp ],
  imports: [ BrowserModule ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
