import { Component } from "@angular/core";

@Component({
    selector : "app-parent",
    template : `
    <div class="box">
        <h2>Parent Component</h2>
        <input #ti type="text" (input)="parentmessage = ti.value">
        <h3>Message is {{ parentmessage }}</h3>
        <br>
        <input type="number" (input)="setPower($event)">
        <h3>Power is {{ power }}</h3>
        <h4>Version is {{ parentVersion }} </h4>
        <hr>
        <app-child (versionEvent)="versionEventHandler($event)" [msg]="parentmessage" [power]="power">
            <ul>
                <li>List Item 1</li>
                <li>List Item 2</li>
                <li>List Item 3</li>
            </ul>
            <button>First Button</button>
            <button class="secondbtn">Second Button</button>
            <p>
                Lorem ipsum dolor sit amet, consectetur adipisicing elit. Soluta incidunt provident sit sapiente repellat voluptatibus fugit consectetur explicabo, doloribus, voluptatum molestias iste animi amet, reiciendis consequuntur, repellendus nulla illo. Magnam.
            </p>
        </app-child>
    </div>
    `,
    styles : [`
        .box{
            margin : 20px;
            padding : 20px;
            border : 2px solid grey;
        }
    `]
})
export class ParentComponent{
    parentmessage:string = "default message";
    power:number = 0;
    parentVersion = 0

    setPower(evt:any){
        this.power = evt.target.value;
    }

    versionEventHandler(evt:any){
        // alert("version event happened version is : "+evt);
        this.parentVersion = evt;
    }
}