import { Component, EventEmitter, Input, Output } from "@angular/core";
/*  inputs : ['message'], */
@Component({
    selector : "app-child",
    template : `
    <div class="box">
    <h2>Child Component</h2>
    <hr>
    <ng-content select="p"></ng-content>
    <ng-content select="button.secondbtn"></ng-content>
    <br>
    <br>
    <ng-content select="button"></ng-content>
    <ng-content></ng-content>
    <hr>
    <h3>{{ message }}</h3>    
    <h3>Power is {{ childpower * 2 }}</h3>
    <input #vi [value]="version" (input)="clickHandler(vi.value)" type="range" min="10" max="1000" step="5">
    Version is {{ version }}
    </div>
    `,
    
    styles : [`
    .box{
        margin : 20px;
        padding : 20px;
        border : 2px solid grey;
    }
`]
})
export class ChildComponent{
    @Input('msg') message = "default";
    @Input('power') childpower:number = 0;

    version = 5;

    @Output() versionEvent:EventEmitter<any> = new EventEmitter();

    setVersion(nversion:any){
        this.version = Number(nversion);
    }

    clickHandler(nversion:any){
        // alert("child component's button was clicked")
        this.versionEvent.emit(nversion);
    }
}