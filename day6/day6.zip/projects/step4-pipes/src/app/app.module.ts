import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { GenPipe } from './gen.pipe';
import { CBREPipe } from './cbre.pipe';

@NgModule({
  declarations: [
    AppComponent, GenPipe, CBREPipe
  ],
  imports: [
    BrowserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
