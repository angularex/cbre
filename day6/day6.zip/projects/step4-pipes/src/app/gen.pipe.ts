import { Pipe, PipeTransform } from "@angular/core";

@Pipe({
    name : "gen"
})
export class GenPipe implements PipeTransform{
    transform(heroname:string, herogender:string, herocity:string):string{
        if(herogender === 'male'){
            return "Mr "+heroname +" is from "+ herocity;
        }else{
            return "Miss "+heroname +" is from "+ herocity;
        }
    }
}
