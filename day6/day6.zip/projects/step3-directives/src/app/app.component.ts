import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <h1>{{title}}</h1>
    <hr>
    <div (mouseover)="boxStyle = 'redbox'" (mouseout)="boxStyle = 'greenbox'" [class]="boxStyle">I am Groot</div>
    Show Green : <input type="checkbox" [(ngModel)]="show">
    <div class="txtprops" [class]="'box'" [class.greenbox]="show">I am Groot</div>
    <hr>
    <input type="range" [(ngModel)]="power" min="0" max="10" step="1">{{ power }}
    <hr>
    <div class="txtprops" [ngClass]="{ greenbox : show, redbox : !show, showShadow : power > 5, box : true } ">I am Groot</div>
    <br>
    <button [style.background-color]="btncol">Click Me</button>
    <br>
    <button [style.background-color]="btncol" [style.font-family]="btnfont">Click Me</button>
    <br>
    <button [ngStyle]="{color : btncol, 'font-family' : btnfont}">Click Me</button>
    <hr>
    <div>
    Show Terms and Condition : <input type="checkbox" [(ngModel)]="show">
    <!--fieldset [hidden]="!show" -->
    <fieldset *ngIf="show">
      <legend>Terms and Condition </legend>
      <div>
        <div>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quas quaerat dolores accusantium repellat saepe quam obcaecati ab error esse sint vitae quasi unde assumenda eius exercitationem illo vero, impedit alias.</div>
        <div>Sunt dolorum consequuntur voluptates numquam libero assumenda modi earum neque explicabo qui adipisci sequi, architecto itaque, voluptatem odio, minima totam nostrum quaerat ipsum. Quae placeat rerum, animi esse quis in!</div>
        <div>A quidem ullam dolorum hic labore nostrum, eos eum numquam tempora? Dolorum voluptatibus, accusamus assumenda! Assumenda dolorem eveniet cumque nesciunt consectetur hic. Dolorum tempore delectus sed exercitationem nisi vitae quis.</div>
        <div>Assumenda unde magnam, fugit nihil facilis possimus, reiciendis natus expedita odio, omnis voluptates ipsa porro quo, facere culpa cum dolores! Libero hic dolor debitis maiores voluptas ratione odio dignissimos pariatur?</div>
        <div>Quos, dignissimos vel architecto. Blanditiis, exercitationem eius minus saepe ratione magnam praesentium, corrupti ad qui libero vel quis eligendi quae voluptatibus maiores similique ipsam molestiae dolor ab in voluptates aut.</div>
      </div>
    </fieldset>
    </div>

    <ol>
      <li>{{ avengers[0] }}</li>
      <li>{{ avengers[1] }}</li>
      <li>{{ avengers[2] }}</li>
      <li>{{ avengers[3] }}</li>
    </ol>
    <input #avenger type="text" (change)="avengers.push(avenger.value)">
    <ol>
      <li *ngFor="let hero of avengers">{{ hero }}</li>
    </ol>
    <p ngNonBindable >company {{ CBRE }} is nice </p>
    <div [ngSwitch]="power">
      <h1 *ngSwitchCase="5">Getting ready</h1>
      <h1 *ngSwitchCase="6">Ready to fight</h1>
      <h1 *ngSwitchCase="7">Strong</h1>
      <h1 *ngSwitchCase="8">Very Strong</h1>
      <h1 *ngSwitchCase="9">Unbeatable</h1>
      <h1 *ngSwitchDefault>Recovering</h1>
    </div>


    `,
  styles : [`
  .txtprops{
    color : papayawhip; 
    text-align:center; 
    font-family:sans-serif;
    line-height : 100px;
    font-size : 36px;
    background-color:silver; 
  }
  .box{
      margin : 10px;
      width : 200px;
      height : 100px;
      border : 2px dotted grey;
  }
  .greenbox{
      background-color:darkseagreen; 
  }
  .redbox{
      background-color:crimson; 
  }
  .showShadow{
    box-shadow : 10px 10px 10px 10px black;
  }
`]
})
export class AppComponent {
  title = 'Binding & Directives in Angular';
  boxStyle = 'greenbox';
  show = false;
  power = 0;
  btncol = 'yellow';
  btnfont = 'impact';

  avengers = ["Ironman","Hulk","Thor","Spiderman","Black Panther"]
}
