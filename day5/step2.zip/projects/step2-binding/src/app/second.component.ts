import { Component } from "@angular/core";

@Component({
    selector : "app-second",
    template : `
    <h2> Class and Style binding </h2>
    <div (mouseover)="boxStyle = 'redbox'" (mouseout)="boxStyle = 'greenbox'" [class]="boxStyle">I am Groot</div>
    Show Green : <input type="checkbox" [(ngModel)]="showgreen">
    <div [class.greenbox]="showgreen">I am Groot</div>

    `,
    styles : [`
        .greenbox{
            margin : 10px;
            background-color:darkseagreen; 
            color : papayawhip; 
            text-align:center; 
            font-family:sans-serif;
            font-size : 36px;
            width : 200px;
            height : 100px;
            line-height : 100px;
        }
        .redbox{
            margin : 10px;
            background-color:crimson; 
            color : papayawhip; 
            text-align:center; 
            font-family:sans-serif;
            font-size : 36px;
            width : 200px;
            height : 100px;
            line-height : 100px;
        }
    `]
})
export class SecondComp{
    boxStyle = 'greenbox';
    showgreen = false;
}