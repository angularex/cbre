import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <h1> {{ title }} </h1>
    <h1 [innerHTML]="title"></h1>
    <h1 [innerText]="title"></h1>
    <h1 [textContent]="title"></h1>
    <h1 bind-innerHTML="title"></h1>
    <hr>
    <h1 innerHTML="{{title}}"></h1>
    <hr>
    <input value="{{title}}" type="text">
    <br>
    <input [value]="title" type="text">
    <br>
    <input bind-value="title" type="text">
    <br>
    <img [src]="batman" alt="">
    <br>
    <button [disabled]="agree">Click Me</button>
    <br>
    <button (click)="saymessage()">Show Message</button>
    <br>
    <input #ti type="text" [value]="title" (change)="title = ti.value" >
    <br>
    <input type="number" [value]="power" (input)="changePowerAgain($event)" >
    <br>
    <input type="number" [(ngModel)]="power" >
    <input #pow type="range" [value]="power" (input)="changePower(pow.value)" >
    Power {{ power }}
    <hr>
    <app-second></app-second>
  `,
  styles: [

  ]
})
export class AppComponent {
  // properties
  title:string = 'Welcome to your life';
  batman:string = "assets/images/batman.jpg";
  agree:boolean = false;
  power = "1";

  // methods
  saymessage(){
    // alert("you clicked the button");
    this.title = "you clicked the button"
  }
  changePower(npower:any){
    // alert("you clicked the button");
    // this.power++;
    this.power = npower;
  }
  changePowerAgain(evt:any){
    this.power = evt.target.value;
  }

}
