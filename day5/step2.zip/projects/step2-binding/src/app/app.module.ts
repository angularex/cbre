import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { SecondComp } from './second.component';
import { FormsModule } from '@angular/forms';

@NgModule({
  /* components, pipes, directives */
  declarations: [ AppComponent , SecondComp ],
  /* external modules that are used in this module */
  imports: [ BrowserModule, FormsModule ],
  /* list of services that provide data */
  providers: [],
  /* list of components that are part of main html file */
  bootstrap: [AppComponent]
})
export class AppModule { }
