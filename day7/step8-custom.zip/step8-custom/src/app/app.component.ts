import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
  <h2>{{ title }}</h2>  
  <ng-template [ngIf]="show"> {{ title }} </ng-template>  
  <div style="display:flex">
    <app-cbre></app-cbre>
    <app-cbre></app-cbre>
    <app-cbre></app-cbre>
    <app-cbre></app-cbre>
  </div>
  <div> {{ 'Vijay' | cbre }} </div>
  <div> {{ 'Kiran' | cbre }} </div>
  <div> {{ 'Lokesh' | cbre }} </div>
  <div> {{ 'Kashyap' | cbre }} </div>
  <div> {{ 'Saboor' | cbre }} </div>
  <div> {{ 'Shravan' | cbre }} </div>
  <div> {{ 'Bharat' | cbre }} </div>

  <div class="cbre_dir" >Sample Text 1</div>
  <div>Sample Text 2</div>
  <div class="cbre_dir" >Sample Text 3</div>
  <div>Sample Text 4</div>
  <div class="cbre_dir" >Sample Text 5</div>
  `,
  styles: []
})
export class AppComponent {
  title = 'Customize Angular';
  show = false;

}
