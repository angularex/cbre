import { Directive, ElementRef, Input } from "@angular/core";
/* 
tag : cbre_dir
    ng-template
    ng-content

attribute : [cbre_dir]
    ngClass
    ngStyle
    ngFor
    ngIf
    ngSwitch

class : .cbre_dir
*/
@Directive({
    selector : ".cbre_dir"
})
export class CBREDirective{
    // @Input() cbre_dir:any = ""
    constructor(private er:ElementRef){
       // 
    }
    ngOnInit(){
        // this.er.nativeElement.setAttribute("style",`background-color: ${this.color}`)
        // this.er.nativeElement.innerHTML = "<div style='background-color:"+this.cbre_dir+"'> Welcome to CBRE you assigned | "+this.cbre_dir+" </div>";
        this.er.nativeElement.innerHTML = "<div> Welcome to CBRE </div>";
    }
}