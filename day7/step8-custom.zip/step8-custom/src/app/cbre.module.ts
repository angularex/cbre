import { NgModule } from "@angular/core";
import { CbreComponent } from "./cbre.component";
import { CBREPipe } from "./cbre.pipe";
import { CBREDirective } from "./cbre.directive";

@NgModule({
    declarations :[CbreComponent, CBREPipe, CBREDirective],
    exports : [CbreComponent, CBREPipe, CBREDirective]
})
export class CBREModule{

}