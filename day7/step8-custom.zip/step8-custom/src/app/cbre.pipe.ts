import { Pipe, PipeTransform } from "@angular/core";

@Pipe({
    name : "cbre"
})
export class CBREPipe implements PipeTransform{
    transform(initialvalue:string):string{
       return initialvalue+" is CBREite";
    }
}