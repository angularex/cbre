import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { CBREModule } from './cbre.module';

@NgModule({
  declarations: [ AppComponent ],
  imports: [ BrowserModule, CBREModule ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
