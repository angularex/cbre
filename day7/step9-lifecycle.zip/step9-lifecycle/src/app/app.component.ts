import { Component, ElementRef, QueryList, ViewChild, ViewChildren } from '@angular/core';
import { CbreComponent } from './cbre.component';

@Component({
  selector: 'app-root',
  template: `
    <h1>{{ title }}</h1>
    <h2 #heading2>Sample Text</h2>
    
    <app-cbre #cbreComp1></app-cbre>
    <app-cbre #cbreComp2></app-cbre>
    <app-cbre #cbreComp3></app-cbre>
    <app-cbre #cbreComp4></app-cbre>
    <!-- 
    <app-cbre></app-cbre>
    <app-cbre></app-cbre>
    <app-cbre></app-cbre>
    <app-cbre></app-cbre>
    -->
    <!-- 
    <button (click)="getDetails()">Get Details</button>
    <input #ti type="text" (change)="changeCompTitle(ti.value)">
    <input #ci type="text" (change)="changeCompColor(ci.value)"> 
    -->
    <button (click)="setTitleToAll()">Set Title to all</button>
  
    <app-child title="app value for title"></app-child>
    `,
  styles: []
})
export class AppComponent {
  title = 'step9-lifecycle | view Child and view Children';
  // @ViewChild("heading2") head2?:ElementRef<HTMLHeadingElement>;
  // @ViewChild(CbreComponent) cbre:CbreComponent = new CbreComponent();

  // @ViewChild('cbreComp1') cbre1?:CbreComponent;
  // @ViewChild('cbreComp2') cbre2?:CbreComponent;
  // @ViewChild('cbreComp3') cbre3?:CbreComponent;
  // @ViewChild('cbreComp4') cbre4?:CbreComponent;

   @ViewChildren('cbreComp1, cbreComp2, cbreComp3, cbreComp4') cbre?:QueryList<CbreComponent>;
  // @ViewChildren(CbreComponent) cbre?:CbreComponent = new CbreComponent();
  //   @ViewChildren(CbreComponent) cbre?:QueryList<CbreComponent>;

  /* getDetails(){
    console.log(this.head2?.nativeElement.innerHTML)
  } */

  /* changeCompTitle(ntitle:any){
    this.cbre.changeTitle(ntitle)
  }
  changeCompColor(ncolor:any){
    this.cbre.changeColor(ncolor)
  } */
  setTitleToAll(){
    this.cbre?.forEach((val:any)=> {
      val.changeTitle("changed");
      val.changeColor("orange");
    })
    // console.log(this.cbre.forEach)
  }

constructor(){
    console.log("AppComponent's was constructor called")
}
ngOnInit(){
    console.log("AppComponent's was ngOnInit called")
}
ngOnChanges(){
    console.log("AppComponent's was ngOnChanges called")
}
ngAfterViewInit(){
    console.log("AppComponent's was ngAfterViewInit called")
}
ngAfterViewChecked(){
    console.log("AppComponent's was ngAfterViewChecked called")
}
ngAfterContentInit(){
    console.log("AppComponent's was ngAfterContentInit called")
}
ngAfterContentChecked(){
    console.log("AppComponent's was ngAfterContentChecked called")
}

}
