import { Component } from '@angular/core';

@Component({
  selector: 'app-cbre',
  template: `
    <h3>{{ title }}</h3>
    <div class="cbre_box" [style.background-color]="selectedCol"></div>
  `,
  styles: [`
  .cbre_box{
    width : 250px;
    height : 100px;
    border : 1px dotted grey;
  }
  `]
})
export class CbreComponent {
  title = "CBRE Component";
  selectedCol:any = "grey";

  changeTitle(arg:any){
    this.title = arg;
  }
  
  changeColor(arg:any){
    this.selectedCol = arg;
  }
}
