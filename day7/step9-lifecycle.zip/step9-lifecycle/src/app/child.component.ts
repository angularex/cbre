import { AfterContentChecked, AfterContentInit, AfterViewChecked, AfterViewInit, Component, Input, OnChanges, OnDestroy, OnInit } from "@angular/core";

@Component({
    selector : "app-child",
    template : `
    <h3>{{ title }}</h3>
    `
})
export class ChildComp implements OnInit, OnChanges, AfterViewInit, AfterViewChecked, AfterContentInit, AfterContentChecked, OnDestroy{
    @Input() title = "default";
    constructor(){
        console.log("ChildComponent's was constructor called")
    }
    ngOnInit(){
        console.log("ChildComponent's was ngOnInit called")
    }
    ngOnChanges(changes:any){
        console.log("ChildComponent's was ngOnChanges called", changes)
    }
    ngAfterViewInit(){
        console.log("ChildComponent's was ngAfterViewInit called")
    }
    ngAfterViewChecked(){
        console.log("ChildComponent's was ngAfterViewChecked called")
    }
    ngAfterContentInit(){
        console.log("ChildComponent's was ngAfterContentInit called")
    }
    ngAfterContentChecked(){
        console.log("ChildComponent's was ngAfterContentChecked called")
    }
    ngOnDestroy(){
        console.log("ChildComponent's was ngOnDestroy called")
    }
}