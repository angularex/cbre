import { Component } from '@angular/core';
import { UserService } from './user.service';

@Component({
  selector: 'app-root',
  template: `
    <h1>{{ title }}</h1>
    <button (click)="makeAjaxCall(1)">1st set</button>
    <button (click)="makeAjaxCall(2)">2nd set</button>
    <table>
      <thead>
        <tr>
          <th>SL#</th>
          <th>User Id</th>
          <th>eMail</th>
          <th>Full Name</th>
          <th>Mugshot</th>
        </tr>
      </thead>
      <tbody>
        <tr *ngFor="let user of data.data; index as idx; odd as od; even as ev" [class.red]="od" [class.orange]="ev" >
          <td>{{ idx+1 }}</td>
          <td>{{ od }} {{ ev }} {{ user.id }}</td>
          <td>{{ user.email }}</td>
          <td>{{ user.first_name+" "+user.last_name }}</td>
          <td>
            <img width="50" [src]="user.avatar" alt="{{ user.first_name+' '+user.last_name }}">
          </td>
        </tr>
      </tbody>
    </table>
  `,
  styles: [`
  .orange{
    background-color : grey
  }
  .red{
    background-color : silver
  }
  `]
})
export class AppComponent {
  title = 'Using Http';
  data:any = {};
  constructor(private us:UserService){
    // this.us.getData().subscribe( res => this.data = res );
  }
  makeAjaxCall(num:any){
    this.us.getData(num).subscribe( res => this.data = res );
  }
}
