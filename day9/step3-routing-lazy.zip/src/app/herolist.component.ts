import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-herolist',
  template: `
    <p>
      herolist works!
    </p>
  `,
  styles: []
})
export class HerolistComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
