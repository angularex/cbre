import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { HomeComponent } from './components/home.component';
import { LoginComponent } from './components/login.component';
import { LogoutComponent } from './components/logout.component';
import { ProfileComponent } from './components/profile.component';
import { RouterModule } from '@angular/router';
import { AuthGuard } from './auth.guard';
import { authGuardFun } from './auth.guard-fun';
import { AuthService } from './auth.service';

@NgModule({
  declarations: [ AppComponent, HomeComponent, LoginComponent, LogoutComponent, ProfileComponent ],
  imports: [ BrowserModule, RouterModule.forRoot([
    { path : '', component:HomeComponent },
    { path : 'login', component:LoginComponent },
    { path : 'logout', component:LogoutComponent },
    { path : 'profile', component:ProfileComponent, canActivate:[authGuardFun] },
    { path : '**', redirectTo:"", pathMatch:"full" },
  ]) ],
  providers: [AuthService],/* required for navigation in the main component */
  bootstrap: [AppComponent]
})
export class AppModule { }
