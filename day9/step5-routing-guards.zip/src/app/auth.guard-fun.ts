import { inject } from "@angular/core";
import { AuthService } from "./auth.service";
import { Router } from "@angular/router";

export let authGuardFun = () => {
    let auth = inject(AuthService);
    let router = inject(Router);
    if(!auth.isLogged){
        router.navigateByUrl('logout')
        return false;
    }else{
        return true
    }
}