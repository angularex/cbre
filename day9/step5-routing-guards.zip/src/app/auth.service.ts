import { Injectable } from "@angular/core";

@Injectable()
export class AuthService{
    isLogged = false;
    login(){
        this.isLogged = true;
    }
    logout(){
        this.isLogged = false;
    }
}