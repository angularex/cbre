import { Component } from "@angular/core";

@Component({
    selector : 'app-home',
    template : `
    <div>
        <h2>{{ title }}</h2>
    </div>
    `
})
export class HomeComponent{ 
    title = "Home Component"
}