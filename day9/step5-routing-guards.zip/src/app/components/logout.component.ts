import { Component } from "@angular/core";

@Component({
    selector : 'app-logout',
    template : `
    <div>
        <h2>{{ title }}</h2>
    </div>
    `
})
export class LogoutComponent{ 
    title = "Logout Component"
}