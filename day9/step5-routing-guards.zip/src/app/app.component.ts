import { Component } from '@angular/core';
import { AuthService } from './auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-root',
  template: `
    <h1>Welcome to {{title}}!</h1>
    <ul>
      <li> <a class="nav-link" [routerLink]="['']">Home</a> </li>
      <li> <a class="nav-link" [routerLink]="['login']">Login</a> </li>
      <li> <a class="nav-link" [routerLink]="['logout']">Logout</a> </li>
      <li> <a class="nav-link" [routerLink]="['profile']">Profile</a> </li>
    </ul>
    <button [disabled]="authServ.isLogged" (click)="loginEvent()">Login</button>
    <button [disabled]="!authServ.isLogged" (click)="logoutEvent()">Logout</button>
    <hr>
    <router-outlet></router-outlet>
    
  `,
  styles: []
})
export class AppComponent {
  title = 'routing-106-guards';
  constructor(public authServ:AuthService, private router:Router){
    // empty
  }
  loginEvent(){
    this.authServ.login();
  }
  logoutEvent(){
    this.authServ.logout();
    this.router.navigateByUrl("logout");
  }
}
