import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-superman',
  template: `
    <h2>
      Superman works!
    </h2>
    <h3>Units : {{ args }}</h3>
  `,
  styles: ``
})
export class SupermanComponent {
  args:any = "0";
  constructor( private ar:ActivatedRoute){
    // emtpy
  }
  ngOnInit(){
    // console.log(this.ar.snapshot.params['qty']);
    this.args = this.ar.snapshot.params['qty']
  }
}
