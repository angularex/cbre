import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <h1>Welcome to {{title}}!</h1>
    <ul>
      <li> <a [routerLink]="['batman']">Batman</a> </li>
      <li> <a [routerLink]="['superman']">Superman</a> </li>
      <li> <a [routerLink]="['superman']">Superman with args</a> </li>
      <li> <a [routerLink]="['aquaman']">Aquaman</a> </li>
      <li> <a [routerLink]="['cyborg']">Cyborg</a> </li>
      <li> <a [routerLink]="['wonderwomen']">Wonder Women</a> </li>
      <li> <a [routerLink]="['flash']">Flash</a> </li>
      <li> <a [routerLink]="['hulk']">Hulk</a> </li>
   </ul>
    <hr>
    <router-outlet></router-outlet>
  `,
  styles: []
})
export class AppComponent {
  title = 'step2-routing-fun';
}
