import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-batman',
  template: `
    <h2>
      Batman works!
    </h2>
    <input [(ngModel)]="batargs" type="text">
    <button (click)="navToSuper()">Send Message</button>
  `,
  styles: ``
})
export class BatmanComponent {
  batargs:any;
  constructor(private router:Router){
  // empty
  }
  navToSuper(){
    this.router.navigate(['superman',this.batargs]);
    // this.router.navigateByUrl('superman')
  }
}
