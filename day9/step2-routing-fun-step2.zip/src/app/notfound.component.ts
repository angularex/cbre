import { Component } from '@angular/core';

@Component({
  selector: 'app-notfound',
  template: `
    <h2>
      notfound works!
    </h2>
  `,
  styles: ``
})
export class NotfoundComponent {

}
