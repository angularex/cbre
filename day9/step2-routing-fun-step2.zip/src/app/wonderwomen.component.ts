import { Component } from '@angular/core';

@Component({
  selector: 'app-wonderwomen',
  template: `
    <h2>
      Wonder Women works!
    </h2>
  `,
  styles: ``
})
export class WonderwomenComponent {

}
