import { Component, Input } from "@angular/core";

@Component({
    selector : "app-nav",
    template : `
    <!--
    <ul>
    <li> <a href="batman">Batman</a> </li>
    <li> <a href="superman">Superman</a> </li>
    </ul>
    -->
    <!--
    <ul>
      <li> <a [routerLink]="['batman']">Batman</a> </li>
      <li> <a [routerLink]="['superman']">Superman</a> </li>
      <li> <a [routerLink]="['aquaman']">Aquaman</a> </li>
      <li> <a [routerLink]="['cyborg']">Cyborg</a> </li>
      <li> <a [routerLink]="['wonderwomen']">Wonder Women</a> </li>
      <li> <a [routerLink]="['flash']">Flash</a> </li>
      <li> <a [routerLink]="['hulk']">Hulk</a> </li>
      </ul>
      -->
    <ul>
        <li> <a [routerLink]="['batman']">Batman</a> </li>
        <li> <a [routerLink]="['superman']">Superman</a> </li>
        <li> <a [routerLink]="['superman', data]">Superman with args</a> </li>
        <li> <a [routerLink]="['aquaman']">Aquaman</a> </li>
        <li> <a [routerLink]="['cyborg']">Cyborg</a> </li>
        <li> <a [routerLink]="['wonderwomen']">Wonder Women</a> </li>
        <li> <a [routerLink]="['flash']">Flash</a> </li>
        <li> <a [routerLink]="['hulk']">Hulk</a> </li>
     </ul>
    `
})
export class NavComp{
    @Input() data:any = 0;
}