import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-cyborg',
  template: `
    <h2>
      cyborg works!
    </h2>
    <button (click)="navToBat()">Navigate To Batman</button>
  `,
  styles: ``
})
export class CyborgComponent {
  constructor(private router:Router){
    //empty
  }
  navToBat(){
    // this.router.navigate(['batman']);
    this.router.navigateByUrl('batman')
  }
}
