import { Route, Routes } from "@angular/router";
import { DetailedComp } from "./detailed.component";
import { ListComp } from "./list.component";

let home:Route = { path : "", component:ListComp }
let detailpage:Route = { path : "detail/:selected", component:DetailedComp }

export let heroRoutes:Routes = [home, detailpage]