import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { ListComp } from './list.component';
import { RouterModule } from '@angular/router';
import { heroRoutes } from './app.routes';
import { DetailedComp } from './detailed.component';

@NgModule({
  declarations: [
    AppComponent, ListComp, DetailedComp
  ],
  imports: [
    BrowserModule, RouterModule.forRoot(heroRoutes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
