import { Component, Input } from "@angular/core";
import { Router } from "@angular/router";

@Component({
    selector : "app-list",
    template : `
     <ul class="nav">
        <li *ngFor="let hero of herolist" (click)="navigate(hero.name)" class="nav-item"> <a class="nav-link" routerLinkActive="bg-warning" routerLink="detail/{{ hero.name }}">{{ hero.name }}</a> </li>
     </ul>
     <router-outlet></router-outlet>
    `
})
export class ListComp{
    @Input() herolist:any;

    constructor(private router:Router){
        // empty
    }

    navigate(args:any){
        this.router.navigate([args])
    }
}    