import { Component, OnInit } from "@angular/core";
import { FormBuilder, FormControl, FormGroup, Validators } from "@angular/forms";

@Component({
    selector : 'app-reactive-builder-form',
    template : `
    <h2>Reactive Builder Form</h2>
    <form [formGroup]="userForm">
        <div class="mb-3">
            <label class="form-label" for="uname">User Name</label>
            <input formControlName="username" class="form-control" id="uname" name="uname">
            <span *ngIf="userForm.get('username').touched && userForm.get('username').invalid" class="errormessage">Please enter your name</span>
        </div>
        <div class="mb-3">
            <label class="form-label" for="uage">User Age</label>
            <input formControlName="userage" class="form-control" id="uage" name="uage" type="number" >
            <span *ngIf="userForm.get('userage').touched && userForm.get('userage').invalid" class="errormessage">Please enter your age </span>
        </div>
        <div class="mb-3">
            <label class="form-label" for="umail">User eMail</label>
            <input formControlName="usermail"  class="form-control" id="umail" name="umail" type="email">
            <span *ngIf="userForm.get('usermail').touched && userForm.get('usermail').invalid" class="errormessage">Please enter your email</span>
        </div>
        <div class="mb-3">
           <button  class="btn btn-primary" type="submit">Submit</button>
        </div>
    </form>
    <button (click)="fillNameFun()">Fill Name</button>
    <button (click)="fillFormFun()">Fill Form</button>
    <ul>
        <li>User Name : {{ userForm.get('username').value }}</li>
        <li>User Age : {{ userForm.get('userage').value }}</li>
        <li>User eMail : {{ userForm.get('usermail').value }}</li>
    </ul>
    <ul>
        <li *ngIf="userForm.get('username').touched">User Name is Touched</li>
        <li *ngIf="userForm.get('username').untouched">User Name is UnTouched</li>
        <li *ngIf="userForm.get('username').pristine">User Name is Pristine</li>
        <li *ngIf="userForm.get('username').dirty">User Name is Dirty</li>
        <li *ngIf="userForm.get('username').valid">User Name is Valid</li>
        <li *ngIf="userForm.get('username').invalid">User Name is InValid</li>
    </ul>
    <ul>
        <li *ngIf="userForm.get('userage').touched" >User Age is Touched</li>
        <li *ngIf="userForm.get('userage').untouched" >User Age is UnTouched</li>
        <li *ngIf="userForm.get('userage').pristine" >User Age is Pristine</li>
        <li *ngIf="userForm.get('userage').dirty" >User Age is Dirty</li>
        <li *ngIf="userForm.get('userage').valid" >User Age is Valid</li>
        <li *ngIf="userForm.get('userage').invalid" >User Age is InValid</li>
    </ul>
    <ul>
        <li *ngIf="userForm.get('usermail').touched" >User eMail is Touched</li>
        <li *ngIf="userForm.get('usermail').untouched" >User eMail is UnTouched</li>
        <li *ngIf="userForm.get('usermail').pristine" >User eMail is Pristine</li>
        <li *ngIf="userForm.get('usermail').dirty" >User eMail is Dirty</li>
        <li *ngIf="userForm.get('usermail').valid" >User eMail is Valid</li>
        <li *ngIf="userForm.get('usermail').invalid" >User eMail is InValid</li>
    </ul>
    
    `,
    styles : [`
        .errormessage{
            color : crimson
        }
        input.ng-invalid.ng-touched{
            border : 3px solid crimson
        }
        input.ng-valid.ng-touched{
            border : 3px solid darkseagreen
        }
    `]
})
export class ReactiveBuilderForm implements OnInit{
    userForm:any;
    constructor(private fb:FormBuilder){
        // empty
    }
    ngOnInit(){
        this.userForm = this.fb.group({
            username : ['',Validators.required],
            userage : ['',[Validators.required, Validators.min(18), Validators.max(90)]],
            usermail : ['',[Validators.required, Validators.pattern(".+@.+")]],
        })
    }

    fillNameFun(){
        this.userForm.patchValue({
            username : "Bruce"
        })
    }
    fillFormFun(){
        this.userForm.setValue({
            username : "Peter Parker",
            userage : 19,
            usermail : "peter@parker.com"
        })
    }
}