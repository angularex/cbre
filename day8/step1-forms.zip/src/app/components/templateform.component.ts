import { Component } from "@angular/core";

@Component({
    selector : 'app-template-form',
    template : `
    <h2>Template Form</h2>
    <form action="#" method="get">
        <div class="mb-3">
            <label class="form-label" for="uname">User Name</label>
            <input #username="ngModel" [(ngModel)]="user.name" class="form-control" id="uname" required name="uname" type="text">
            <span *ngIf="username.touched && username.invalid" class="errormessage">Please enter your name</span>
        </div>
        <div class="mb-3">
            <label class="form-label" for="uage">User Age</label>
            <input #userage="ngModel" [(ngModel)]="user.age" class="form-control" id="uage" step="1" required min="18" max="90" name="uage" type="number">
            <span *ngIf="userage.touched && userage.invalid" class="errormessage">Please enter your age </span>
        </div>
        <div class="mb-3">
            <label class="form-label" for="umail">User eMail</label>
            <input #usermail="ngModel" [(ngModel)]="user.email" class="form-control" id="umail" required pattern=".+@.+" name="umail" type="email">
            <span *ngIf="usermail.touched && usermail.invalid" class="errormessage">Please enter your email</span>
        </div>
        <div class="mb-3">
           <button class="btn btn-primary" type="submit">Submit</button>
        </div>
    </form>
    <ul>
        <li>User Name : {{ user.name }}</li>
        <li>User Age : {{ user.age }}</li>
        <li>User eMail : {{ user.email }}</li>
    </ul>
    <ul>
        <li *ngIf="username.touched">User Name is Touched</li>
        <li *ngIf="username.untouched">User Name is UnTouched</li>
        <li *ngIf="username.pristine">User Name is Pristine</li>
        <li *ngIf="username.dirty">User Name is Dirty</li>
        <li *ngIf="username.valid">User Name is Valid</li>
        <li *ngIf="username.invalid">User Name is InValid</li>
    </ul>
    <ul>
        <li *ngIf="userage.touched" >User Age is Touched</li>
        <li *ngIf="userage.untouched" >User Age is UnTouched</li>
        <li *ngIf="userage.pristine" >User Age is Pristine</li>
        <li *ngIf="userage.dirty" >User Age is Dirty</li>
        <li *ngIf="userage.valid" >User Age is Valid</li>
        <li *ngIf="userage.invalid" >User Age is InValid</li>
    </ul>
    <ul>
        <li *ngIf="usermail.touched" >User eMail is Touched</li>
        <li *ngIf="usermail.untouched" >User eMail is UnTouched</li>
        <li *ngIf="usermail.pristine" >User eMail is Pristine</li>
        <li *ngIf="usermail.dirty" >User eMail is Dirty</li>
        <li *ngIf="usermail.valid" >User eMail is Valid</li>
        <li *ngIf="usermail.invalid" >User eMail is InValid</li>
    </ul>
    
    `,
    styles : [`
        .errormessage{
            color : crimson
        }
        input.ng-invalid.ng-touched{
            border : 3px solid crimson
        }
        input.ng-valid.ng-touched{
            border : 3px solid darkseagreen
        }
    `]
})
export class TemplateForm{
    user = {
        name : "",
        age : 0,
        email : ""
      }
}