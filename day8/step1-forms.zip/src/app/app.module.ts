import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { TemplateForm } from './components/templateform.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ReactiveGroupForm } from './components/reactive-group.component';
import { ReactiveBuilderForm } from './components/reactive-builder-form.component';

@NgModule({
  declarations: [ AppComponent, TemplateForm, ReactiveGroupForm, ReactiveBuilderForm ],
  imports: [ BrowserModule, FormsModule, ReactiveFormsModule ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
