import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <div class="container">
      <h1>Welcome to {{title}}!</h1>
      <app-template-form></app-template-form>
      <app-reactive-group-form></app-reactive-group-form>
      <app-reactive-builder-form></app-reactive-builder-form>
    </div>
  `,
  styles: []
})
export class AppComponent {
  title = 'Forms in Angular';
}
