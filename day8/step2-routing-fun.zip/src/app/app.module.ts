import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { HomeComponent } from './home.component';
import { BatmanComponent } from './batman.component';
import { SupermanComponent } from './superman.component';
import { CyborgComponent } from './cyborg.component';
import { AquamanComponent } from './aquaman.component';
import { WonderwomenComponent } from './wonderwomen.component';
import { NotfoundComponent } from './notfound.component';
import { RouterModule } from '@angular/router';
import { approutes } from './app.routes';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    BatmanComponent,
    SupermanComponent,
    CyborgComponent,
    AquamanComponent,
    WonderwomenComponent,
    NotfoundComponent
  ],
  imports: [ BrowserModule, RouterModule.forRoot(approutes) ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
