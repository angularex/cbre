import { Route, Routes } from "@angular/router";
import { HomeComponent } from "./home.component";
import { BatmanComponent } from "./batman.component";
import { SupermanComponent } from "./superman.component";
import { AquamanComponent } from "./aquaman.component";
import { CyborgComponent } from "./cyborg.component";
import { WonderwomenComponent } from "./wonderwomen.component";
import { NotfoundComponent } from "./notfound.component";

let homeroute:Route = { path : "", component : HomeComponent }/* Default Route */
let batmanroute:Route = { path : "batman", component : BatmanComponent } /* named routes */
let supermanroute:Route = { path : "superman", component : SupermanComponent } /* named routes */
let aquamanroute:Route = { path : "aquaman", component : AquamanComponent } /* named routes */
let cyborgroute:Route = { path : "cyborg", component : CyborgComponent } /* named routes */
let wonderwomenroute:Route = { path : "wonderwomen", component : WonderwomenComponent }/* named routes */
let flashroute:Route = { path : "flash", redirectTo:"batman", pathMatch: "full" }/* named routes */
let notfoundroute:Route = { path : "**", component : NotfoundComponent }/* wildcard routes */


export let approutes:Routes = [homeroute, batmanroute, supermanroute, aquamanroute, cyborgroute, wonderwomenroute,flashroute, notfoundroute]