import { Component } from '@angular/core';

@Component({
  selector: 'app-aquaman',
  template: `
    <h2>
      aquaman works!
    </h2>
    <ul>
      <li> <a [routerLink]="['/superman']">Superman</a> </li>
    </ul>
  `,
  styles: ``
})
export class AquamanComponent {

}
