import { Component } from '@angular/core';

@Component({
  selector: 'app-batman',
  template: `
    <h2>
      batman works!
    </h2>
  `,
  styles: ``
})
export class BatmanComponent {

}
