import { Component } from '@angular/core';

@Component({
  selector: 'app-wonderwomen',
  template: `
    <h2>
      wonderwomen works!
    </h2>
  `,
  styles: ``
})
export class WonderwomenComponent {

}
