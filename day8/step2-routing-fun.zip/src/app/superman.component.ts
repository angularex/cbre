import { Component } from '@angular/core';

@Component({
  selector: 'app-superman',
  template: `
    <h2>
      superman works!
    </h2>
  `,
  styles: ``
})
export class SupermanComponent {

}
